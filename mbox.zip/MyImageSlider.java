package com.cdhgold.shop.mbox;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;


public class MyImageSlider extends Fragment {
    int imageid;
    // static method to create the MyImageSlider Fragment containing image
    public  static MyImageSlider newInstance(int id)
    {
        MyImageSlider slider=new MyImageSlider();
        Bundle b=new Bundle();
        b.putInt("imageid", id);
        slider.setArguments(b);
        return slider;
    }
    // get the image id from fragment in this method although we can also get in onCreateView.
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        imageid=getArguments().getInt("imageid");
    }
    // this method returns the view containing the required which is set while creating instance of fragment
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.adapterview, container, false);
        ImageView iv=(ImageView)view.findViewById(R.id.myimage);
        iv.setImageResource(imageid);
        return view;
    }
}
