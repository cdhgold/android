package com.cdhgold.shop.mbox;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;


public class Menu2Fragment extends Fragment {
    ViewPager pager;
    List<Fragment> fragments;
    // list containing id's of images we want to show in viewpager
    // images are in drawable folder
    ArrayList<Integer> images=new ArrayList<Integer>(){{
        add(R.drawable.img01);
        add(R.drawable.img02);
        add(R.drawable.img03);
        add(R.drawable.img04);
        add(R.drawable.img05);
        add(R.drawable.img06);
        add(R.drawable.img07);
        add(R.drawable.img08);
        add(R.drawable.img09);
        add(R.drawable.img10);


    }};
    PagerAdapter adapter;


    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //returning our layout file
        //change R.layout.yourlayoutfilename for each of your fragments
        View view =  inflater.inflate(R.layout.fragment_menu2, container, false);

        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        //you can set the title for your toolbar here for different fragments different titles
        getActivity().setTitle("M복싱 멀티짐 갤러리");
        pager = (ViewPager)view.findViewById(R.id.viewPager);

        //method to create the required fragments to show in viewpager and return as a fragment list
        fragments=getFragments();
        adapter=new PagerAdapter(getFragmentManager(),fragments);
        pager.setAdapter(adapter);

    }
    class PagerAdapter extends FragmentStatePagerAdapter { 
        private List<Fragment> fragments;
        public PagerAdapter(FragmentManager fm, List<Fragment> fragments) {
            super(fm);
            this.fragments = fragments;
        }
        @Override
        public Fragment getItem(int position) {
            return this.fragments.get(position);
        }
        @Override
        public int getCount() {
            return this.fragments.size();
        }
    }

    //method to get list of fragments to be displayed in viewpager
    private List<Fragment> getFragments() {
        List<Fragment> fList = new ArrayList<Fragment>();
        for (int i = 0; i < images.size(); i++) {
            fList.add(MyImageSlider.newInstance(images.get(i)));
        }
        return fList;
    }
}
