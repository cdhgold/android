package com.clt.apps.opus.esd.sce.batch.csmsend.basic;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.log4j.Logger;

import com.clt.framework.core.layer.event.EventException;
import com.clt.scheduler.jdbc.JDBCException;
import com.clt.scheduler.jdbc.JDBCWrapper;
import com.clt.scheduler.jdbc.ResultTable;
import com.clt.scheduler.server.BaseJobTrx;
import com.clt.apps.opus.esd.sce.csmsend.basic.CSMSendBC;
import com.clt.apps.opus.esd.sce.csmsend.basic.CSMSendBCImpl;
import com.clt.apps.opus.esd.sce.csmsend.vo.CSMSendVO;

/**
 * @author 
 *
 */
public class CSMSend extends BaseJobTrx {

	private Logger logger = Logger.getLogger(this.getClass().getName());
	
	/**
	 * @param id
	 * @param param_string
	 */
	public CSMSend(String id, String param_string) {
		super(id, param_string);
	}
	
	/* (non-Javadoc)
	 * @see com.clt.scheduler.server.BaseJob#doWork(com.clt.scheduler.jdbc.JDBCWrapper, java.lang.String[])
	 */
	@Override
	public void doWork(JDBCWrapper arg0, String[] arg1) throws Exception {
		logger.info("##### Batch Program : CSMSend  Started ####");
		/*the array values for each result*/
//        String[] result_flags = null;
		ResultTable preVo = wrapper.getResultTable("sce/SearchCSMSendTarget", "csmSend");
		ArrayList<HashMap<String, Object>> list = this.fetchRowSet(preVo);
		CSMSendVO cSMSendVO = new CSMSendVO();
		Map<String, Object> rowMap=null;
		try{
	        if(list != null && list.size() >0){
	//        	result_flags = new String[list.size()];	
	        	Iterator<HashMap<String, Object>> itr = list.iterator();
			    /*getting hashmap from list and making sednvo*/
				for(int i=0;i<list.size();i++){
					//HashMap<String, Object> values = (HashMap<String, Object>)list.get(i);
					rowMap = (Map<String, Object>) itr.next();
					/*setting values into vo manually */
					cSMSendVO.setActRcvDt ((String) rowMap.get("ACT_RCV_DT"));
					cSMSendVO.setActRcvNo ((String) rowMap.get("ACT_RCV_NO"));
					cSMSendVO.setBkgNo ((String) rowMap.get("BKG_NO"));
					cSMSendVO.setActUmchTpCd ((String) rowMap.get("ACT_UMCH_TP_CD"));
					cSMSendVO.setCntrNo ((String) rowMap.get("CNTR_NO"));
					cSMSendVO.setActDt ((String) rowMap.get("ACT_DT"));
					cSMSendVO.setActStsMapgCd ((String) rowMap.get("ACT_STS_MAPG_CD"));
					cSMSendVO.setNodCd ((String) rowMap.get("NOD_CD"));
					
			        logger.info("#### CSMSendVO[" + i +"] of Total Length " + list.size() + "#####"   + "\n" +
					        "[ACT_RCV_DT  ]"   + cSMSendVO.getActRcvDt   ()   + "\n" +
					        "[ACT_RCV_NO   ]"   + cSMSendVO.getActRcvNo    ()   + "\n" +
					        "[BKG_NO  ]"   + cSMSendVO.getBkgNo()   + "\n" +
					        "[ACT_UMCH_TP_CD  ]"   + cSMSendVO.getActUmchTpCd()   + "\n" +
					        "[CNTR_NO  ]"   + cSMSendVO.getCntrNo()   + "\n" +
					        "[ACT_DT  ]"   + cSMSendVO.getActDt()   + "\n" +
					        "[ACT_STS_MAPG_CD  ]"   + cSMSendVO.getActStsMapgCd()   + "\n" +
					        "[NOD_CD  ]"   + cSMSendVO.getNodCd()   + "\n" );
	
			       // result_flags[i] = command.Edi315Send(cSMSendVO);
			        
			        if (searchDupSndRslt(cSMSendVO)) {
						//updateActUmchTpCd(act_rcv_dt, act_rcv_no, "40");
			        	cSMSendVO.setActUmchTpCd("40");
			        	updateActUmchTpCd(cSMSendVO);
						continue;
					}
					
					if ( ((String) rowMap.get("ACT_UMCH_TP_CD")).equals("ZZ")) {
						//String rtnStr = searchBkgBound(bkg_no, bkg_no_split);
						String rtnStr = searchBkgBound(cSMSendVO);
						if (rtnStr.equals("NOT_EXIST")) {
							// Bookng 이 아직 없을 경우에는 cop event seq 만 올리고 빠져나감
							//updateActUmchTpCd(act_rcv_dt, act_rcv_no, act_umch_tp_cd);
							cSMSendVO.setActUmchTpCd((String) rowMap.get("ACT_UMCH_TP_CD"));
							updateActUmchTpCd(cSMSendVO);
						} else if (rtnStr.equals("US_BOUND")) {
							// 미주 일 경우 Flat file 생성 처리를 위해 act_umch_tp_cd 를 수정
							//updateActUmchTpCd(act_rcv_dt, act_rcv_no, "XX");
							cSMSendVO.setActUmchTpCd("XX");
							updateActUmchTpCd(cSMSendVO);
							//insertFlatFile(act_rcv_dt, act_rcv_no);
							insertFlatFile(cSMSendVO);
						} else if (rtnStr.equals("NOT_US_BOUND")) {
							// 미주가 아닌 것으로 판명 난 경우 해당 row 를 삭제
							//deleteCSMTarget(act_rcv_dt, act_rcv_no);
							deleteCSMTarget(cSMSendVO);
						}
					} else {
						//updateActUmchTpCd(act_rcv_dt, act_rcv_no, "XX");
						cSMSendVO.setActUmchTpCd("XX");
						updateActUmchTpCd(cSMSendVO);
						//insertFlatFile(act_rcv_dt, act_rcv_no);
						insertFlatFile(cSMSendVO);
					}
				}//for
	        }//if
	        
			// 2009.02.19 live 반영 현재 아래 부분은 막아 불필요하게 EDI queue 에 쌓이는 것을 막음
			// 차후 sFTP 설정 완료되어 CBP 로의 전송이 가능하게 되면 아래 주석을 풀어야 함
			// 단, 그 이전에 기존에 발생된 SCE_CNTR_STS_MSG_TGT, SCE_CNTR_STS_MSG_FLT_FILE, SCE_CNTR_STS_MSG_SND_RSLT
			// 테이블의 data 를 모두 삭제하여야 queue 전송 시 부하가 발생하지 않는다.
			sendFlatFileIntoQueue();
		} catch (EventException de) {
			wrapper.rollback();
			logger.error("err " + de.toString(), de);
			//throw new EventException(de.getMessage());
	        //TaskErrorEventResponse errorEventResponse = new TaskErrorEventResponse("CSMSendBSC Error");
	        //errorEventResponse.addError(de.getMessage());
	        updateExceptionMessage((String) rowMap.get("ACT_RCV_DT"), (String) rowMap.get("ACT_RCV_NO"), "50");
	        // 오류를 배치작업 Log Manager에 저장된다.
	        return ;
		}catch (Exception de) {
			wrapper.rollback();
			logger.error("err " + de.toString(), de);
			//throw new EventException(de.getMessage());
	        //TaskErrorEventResponse errorEventResponse = new TaskErrorEventResponse("CSMSendBSC Error");
	        //errorEventResponse.addError(de.getMessage());
	        updateExceptionMessage((String) rowMap.get("ACT_RCV_DT"), (String) rowMap.get("ACT_RCV_NO"), "51");
	        // 오류를 배치작업 Log Manager에 저장된다.
	        return ;
		}
		return ;
	}
	
	/**
     * ArrayList - extracting hashmap from ResultTable and putting them into list
     * @param ResultTable
     * @return ArrayList
     * @throws EventException
     */	
	private ArrayList<HashMap<String, Object>> fetchRowSet(ResultTable svcLaneRS) throws EventException{	
    	if(svcLaneRS==null || svcLaneRS.getRowCount()<0){
    		return null;
    	}
    	  
    	ArrayList<HashMap<String, Object>> rowList = null;
    	try{
    		rowList  = new ArrayList<HashMap<String, Object>>();
    		for(int j=0; j < svcLaneRS.getRowCount();j++){
    			rowList.add(svcLaneRS.getValues(j));
    		}
    	}catch(Exception se){
        	logger.error("err "+se.toString(),se);
            throw new EventException(se.getMessage());
    	}
    	return rowList;
    }
	
	/**
	 * parameter 에 해당 되는 전송 성공 log 가 존재하는 지를 확인한다.
	 * 존재한다면 해당 전송은 skip 된다.
	 * 
	 * @param bkg_no
	 * @param bkg_no_split
	 * @param cntr_no
	 * @param act_dt
	 * @param act_sts_mapg_cd
	 * @param nod_cd
	 * @return
	 * @throws EventException
	 */
	private boolean searchDupSndRslt(CSMSendVO cSMSendVO) throws EventException{
		CSMSendBC command = new CSMSendBCImpl();
		boolean isExists = false;
		try {
			isExists = command.searchDupSndRslt(cSMSendVO);
		} catch (EventException e) {
			try{
				wrapper.rollback();
			}catch(JDBCException jE)	{
				logger.error("err " + jE.toString(), jE);
			}
			logger.error("err " + e.toString(), e);
		}
		return isExists;
	}
	
	/**
	 * movement data 의 처리 결과를 update 한다.
	 * 99 : 정상 발생, queue 전송 완료
	 * XX : process 진행 중
	 * 
	 * @param act_rcv_dt
	 * @param act_rcv_no
	 * @param act_umch_tp_cd
	 * @throws EventException
	 */
	private void updateActUmchTpCd(CSMSendVO cSMSendVO) throws EventException {
		CSMSendBC command = new CSMSendBCImpl();
		try{
			wrapper.begin();
			command.updateActUmchTpCd(cSMSendVO);
			wrapper.commit();
		}catch(JDBCException e)	{
			logger.error("err " + e.toString(), e);
		}
	}
	
	/**
	 * booking 정보가 없어서 미주 행인지 판단 못한 건을 차후 판단
	 * @param bkg_no
	 * @param bkg_no_split
	 * @return
	 * @throws EventException
	 */
	private String searchBkgBound(CSMSendVO cSMSendVO) throws EventException {
		CSMSendBC command = new CSMSendBCImpl();
		String rtnStr = command.searchBkgBound(cSMSendVO);
		
		return rtnStr;
	}
	
	/**
	 * movement 발생 건 별로 flat file 을 생성한다.
	 * @param act_rcv_dt
	 * @param act_rcv_no
	 * @return
	 * @throws EventException
	 */
	private synchronized int insertFlatFile(CSMSendVO cSMSendVO) {
		CSMSendBC command = new CSMSendBCImpl();
		int rowCnt=0;
		try{
			
			wrapper.begin();
			rowCnt= command.insertFlatFile(cSMSendVO);
			wrapper.commit();
		} catch(Exception e)	{
			logger.error("err " + e.toString(), e);
		}
		
		return rowCnt;
	}
	
	/**
	 * Exception 발생시 SCE_CNTR_STS_MSG_TGT 의 상태 정보를 수정하여 준다.
	 * @param act_rcv_dt
	 * @param act_rcv_no
	 * @param act_umch_tp_cd
	 */
	private void updateExceptionMessage(String act_rcv_dt, String act_rcv_no, String act_umch_tp_cd) throws EventException {
		CSMSendBC command = new CSMSendBCImpl();
		try {
			wrapper.begin();
			command.updateActUmchTpCd(act_rcv_dt, act_rcv_no, act_umch_tp_cd);
			wrapper.commit();
		}catch(JDBCException e)	{
			logger.error("err " + e.toString(), e);
		}
	}
	
	/**
	 * 불필요한 것으로 판단된 movement target data 를 삭제한다.
	 * (booking 정보가 없어서 미주 행인지 판단 못한 건을 차후 판단시 미주가 아니라고 판단되면 삭제)
	 * @param act_rcv_dt
	 * @param act_rcv_no
	 * @throws EventException
	 */
	private void deleteCSMTarget(CSMSendVO cSMSendVO) throws EventException {
		CSMSendBC command = new CSMSendBCImpl();
		try{ 
			wrapper.begin();
			command.deleteCSMTarget(cSMSendVO);
			wrapper.commit();
		}catch(JDBCException e)	{
			logger.error("err " + e.toString(), e);
		}
	}
	
	/**
	 * 미 전송건 전부 QUEUE 로 전송
	 * @throws EventException
	 */
	private void sendFlatFileIntoQueue() throws EventException {
		CSMSendBC command = new CSMSendBCImpl();
		try{
			wrapper.begin();
			command.sendFlatFileIntoQueue();
			wrapper.commit();
		}catch(JDBCException e)	{
			logger.error("err " + e.toString(), e);
		}
	}
    
	public static void main()  {
		
	}
	
	
}
