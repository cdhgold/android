/**
 * 
 */
package com.clt.apps.opus.esd.sce.batch.csmsend.basic;

import org.apache.log4j.Logger;

import com.clt.apps.opus.esd.sce.csmsend.basic.CSMSendBC;
import com.clt.apps.opus.esd.sce.csmsend.basic.CSMSendBCImpl;
import com.clt.scheduler.jdbc.JDBCWrapper;
import com.clt.scheduler.server.BaseJob;

/**
 * @author 2002701
 *
 */
public class CSMSendEmptyCntr extends BaseJob {

	// log4j logger
	private Logger logger = Logger.getLogger(this.getClass().getName());
	
	public CSMSendEmptyCntr(String id, String param_string) {
		super(id, param_string);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void doWork(JDBCWrapper arg0, String[] arg1) throws Exception {
		// TODO Auto-generated method stub
		CSMSendBC csmsendBC = new CSMSendBCImpl();
		int cnt = csmsendBC.addCSMSendTargetEmptyCntr();
		
		logger.info("CSMSendTargetEmptyCntr rowCnt = " + cnt);
	}

}
