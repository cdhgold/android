/**
 * 
 */
package com.clt.apps.opus.esd.sce.batch.csmsendeur;

import com.clt.scheduler.jdbc.JDBCWrapper;
import com.clt.scheduler.server.BaseJobTrx;

/**
 * @author
 * 
 */
public class CSMSendEmptyCntrEur extends BaseJobTrx {
	public CSMSendEmptyCntrEur(String id, String param_string) {
		super(id, param_string);
	}

	@Override
	public void doWork(JDBCWrapper arg0, String[] arg1) throws Exception {
		wrapper.update("sce/CSMEmtpyCntrEurTarget", "addCSMSendTargetEmptyCntr");
	}
}
