package com.clt.apps.opus.esd.sce.batch.csmsendeur;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.log4j.Logger;

import com.clt.apps.opus.esd.sce.csmsendeur.basic.CSMSendEurBC;
import com.clt.apps.opus.esd.sce.csmsendeur.basic.CSMSendEurBCImpl;
import com.clt.apps.opus.esd.sce.csmsendeur.vo.CSMSendEurVO;
import com.clt.framework.core.layer.event.EventException;
import com.clt.scheduler.jdbc.JDBCException;
import com.clt.scheduler.jdbc.JDBCWrapper;
import com.clt.scheduler.jdbc.ResultTable;
import com.clt.scheduler.server.BaseJobTrx;

/**
 * @author
 */
public class CSMSendEur extends BaseJobTrx {

	// log4j logger
	private Logger logger = Logger.getLogger(this.getClass().getName());

	/**
	 * @param id
	 * @param param_string
	 */
	public CSMSendEur(String id, String param_string) {
		super(id, param_string);
	}

	@Override
	public void doWork(JDBCWrapper arg0, String[] arg1) throws Exception {
		logger.info("##### Batch Program : CSMSend  Started ####");
		ResultTable preVo = wrapper.getResultTable("sce/SearchCSMSendEurTarget", "csmEurSend");
		ArrayList<HashMap<String, Object>> list = this.fetchRowSet(preVo);
		CSMSendEurVO cSMSendEurVO = new CSMSendEurVO();
		Map<String, Object> rowMap = null;
		try {
			if (list != null && list.size() > 0) {
				Iterator<HashMap<String, Object>> itr = list.iterator();
				StringBuilder sb = new StringBuilder();
				for (int i = 0; i < list.size(); i++) {
					rowMap = (Map<String, Object>) itr.next();
					cSMSendEurVO.setActRcvDt((String) rowMap.get("ACT_RCV_DT"));
					cSMSendEurVO.setActRcvNo((String) rowMap.get("ACT_RCV_NO"));
					cSMSendEurVO.setBkgNo((String) rowMap.get("BKG_NO"));
					cSMSendEurVO.setCntrNo((String) rowMap.get("CNTR_NO"));
					cSMSendEurVO.setCsmCntCd((String) rowMap.get("CSM_CNT_CD")); // 국가코드 추가 신규 개발
					cSMSendEurVO.setActUmchTpCd((String) rowMap.get("ACT_UMCH_TP_CD"));
					cSMSendEurVO.setActDt((String) rowMap.get("ACT_DT"));
					cSMSendEurVO.setActStsMapgCd((String) rowMap.get("ACT_STS_MAPG_CD"));
					cSMSendEurVO.setNodCd((String) rowMap.get("NOD_CD"));

					sb.append("#### CSMSendEurVO[" + i + "] of Total Length " + list.size() + "#####" + "\n");
					sb.append("[ACT_RCV_DT  ]" + cSMSendEurVO.getActRcvDt() + "\n");
					sb.append("[ACT_RCV_NO   ]" + cSMSendEurVO.getActRcvNo() + "\n");
					sb.append("[BKG_NO  ]" + cSMSendEurVO.getBkgNo() + "\n");
					sb.append("[CNTR_NO  ]" + cSMSendEurVO.getCntrNo() + "\n");
					sb.append("[CSM_CNT_CD  ]" + cSMSendEurVO.getCsmCntCd() + "\n");
					sb.append("[ACT_UMCH_TP_CD  ]" + cSMSendEurVO.getActUmchTpCd() + "\n");
					sb.append("[ACT_DT  ]" + cSMSendEurVO.getActDt() + "\n");
					sb.append("[ACT_STS_MAPG_CD  ]" + cSMSendEurVO.getActStsMapgCd() + "\n");
					sb.append("[NOD_CD  ]" + cSMSendEurVO.getNodCd() + "\n");
					logger.info(sb.toString());
					sb.setLength(0);

					if (searchDupSndRslt(cSMSendEurVO)) { // Duplicated Data Process (Sent)
						cSMSendEurVO.setActUmchTpCd("40");
						wrapper.begin();
						updateActUmchTpCd(cSMSendEurVO);
						wrapper.commit();
						continue;
					}

					cSMSendEurVO.setActUmchTpCd("XX");
					wrapper.begin();
					updateActUmchTpCd(cSMSendEurVO);
					wrapper.commit();

					wrapper.begin();
					insertFlatFile(cSMSendEurVO);
					wrapper.commit();

					wrapper.begin();
					sendFlatFileIntoQueue(cSMSendEurVO);
					wrapper.commit();
				}
			}

		} catch (EventException de) {
			wrapper.rollback();
			logger.error("err " + de.toString(), de);

			cSMSendEurVO.setActUmchTpCd("50");
			wrapper.begin();
			updateActUmchTpCd(cSMSendEurVO);
			wrapper.commit();
			return;
		} catch (Exception de) {
			wrapper.rollback();
			logger.error("err " + de.toString(), de);

			cSMSendEurVO.setActUmchTpCd("51");
			wrapper.begin();
			updateActUmchTpCd(cSMSendEurVO);
			wrapper.commit();
			return;
		}

		logger.info("\n----------- CSMSendEur End   --------- ");

		return;
	}

	/**
	 * ArrayList - extracting hashmap from ResultTable and putting them into list
	 * 
	 * @param ResultTable
	 * @return ArrayList
	 * @throws EventException
	 */
	private ArrayList<HashMap<String, Object>> fetchRowSet(ResultTable svcLaneRS) throws EventException {
		if (svcLaneRS == null || svcLaneRS.getRowCount() < 0) {
			return null;
		}

		ArrayList<HashMap<String, Object>> rowList = null;
		try {
			rowList = new ArrayList<HashMap<String, Object>>();
			for (int j = 0; j < svcLaneRS.getRowCount(); j++) {
				rowList.add(svcLaneRS.getValues(j));
			}
		} catch (Exception se) {
			logger.error("err " + se.toString(), se);
			throw new EventException(se.getMessage());
		}
		return rowList;
	}

	/**
	 * Parameter 에 해당 되는 전송 성공 Log 가 존재하는 지를 확인한다. 존재한다면 해당 전송은 skip 된다.
	 * 
	 * @param cSMSendEurVO
	 * @return
	 * @throws EventException
	 */
	private boolean searchDupSndRslt(CSMSendEurVO cSMSendEurVO) throws EventException {
		CSMSendEurBC command = new CSMSendEurBCImpl();
		boolean isExists = false;
		try {
			isExists = command.searchDupSndRslt(cSMSendEurVO);
		} catch (EventException e) {
			try {
				wrapper.rollback();
			} catch (JDBCException jE) {
				logger.error("err " + jE.toString(), jE);
			}
			logger.error("err " + e.toString(), e);
		}
		return isExists;
	}

	/**
	 * Movement Data 의 처리 결과를 Update 한다. 99 : 정상 발생, queue 전송 완료 XX : process 진행 중
	 * 
	 * @param cSMSendEurVO
	 * @throws EventException
	 */
	private void updateActUmchTpCd(CSMSendEurVO cSMSendEurVO) throws EventException {
		CSMSendEurBC command = new CSMSendEurBCImpl();
		try {
			command.updateActUmchTpCd(cSMSendEurVO);
		} catch (EventException e) {
			logger.error("err " + e.toString(), e);
		}
	}

	/**
	 * Movement 발생 건 별로 Flat File 을 생성한다.
	 * 
	 * @param cSMSendEurVO
	 * @return
	 * @throws EventException
	 */
	private int insertFlatFile(CSMSendEurVO cSMSendEurVO) throws EventException {
		CSMSendEurBC command = new CSMSendEurBCImpl();
		int rowCnt = 0;
		try {
			rowCnt = command.insertFlatFile(cSMSendEurVO);
		} catch (EventException e) {
			logger.error("err " + e.toString(), e);
		}

		return rowCnt;
	}

	/**
	 * 미 전송 건 전부 QUEUE 로 전송
	 * 
	 * @param cSMSendEurVO
	 * @throws EventException
	 */
	private void sendFlatFileIntoQueue(CSMSendEurVO cSMSendEurVO) throws EventException {
		CSMSendEurBC command = new CSMSendEurBCImpl();
		try {
			command.sendFlatFileIntoQueue(cSMSendEurVO);
		} catch (EventException e) {
			logger.error("err " + e.toString(), e);
		}
	}
}
