package com.clt.apps.opus.esd.sce.batch.csmsendeur;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.log4j.Logger;

import com.clt.framework.core.layer.event.EventException;
import com.clt.scheduler.jdbc.JDBCWrapper;
import com.clt.scheduler.jdbc.ResultTable;
import com.clt.scheduler.server.BaseJobTrx;

public class CSMSendCODEur extends BaseJobTrx {
	private Logger logger = Logger.getLogger(this.getClass().getName());

	/**
	 * @param id
	 * @param param_string
	 */
	public CSMSendCODEur(String id, String param_string) {
		super(id, param_string);
	}

	/**
	 * 
	 */
	@SuppressWarnings("rawtypes")
	public void doWork(JDBCWrapper arg0, String[] arg1) throws Exception {
		logger.info("##### Batch Program : CSMSendCODEur Started ####");
		ResultTable preVo = wrapper.getResultTable("sce/SearchCSMSendCODEurTarget", "getCsmCODEurData");
		ArrayList<HashMap<String, Object>> list = this.fetchRowSet(preVo);

		Map rowMap = null;

		if (list != null && list.size() > 0) {
			HashMap<String, Object> values = (HashMap<String, Object>) list.get(0);
			String param10 = "XX";
			String param20 = (String) values.get("COD_RCV_SEQ");
			wrapper.begin();
			wrapper.update("sce/SearchCSMSendCODEurTarget", "modifySceCodHis", new Object[] { param10, param20 });
			wrapper.commit();
		}

		try {
			if (list != null && list.size() > 0) {
				Iterator itr = list.iterator();
				for (int i = 0; i < list.size(); i++) {
					rowMap = (Map) itr.next();

					String param1 = (String) rowMap.get("BKG_NO");

					/* Invoking */
					wrapper.begin();
					wrapper.update("sce/SearchCSMSendCODEurTarget", "insertCsmCODEurTarget", new Object[] { param1 });
					wrapper.commit();

					String param10 = "99";
					String param20 = (String) rowMap.get("COD_RCV_SEQ");
					wrapper.begin();
					wrapper.update("sce/SearchCSMSendCODEurTarget", "modifySceCodHis", new Object[] { param10, param20 });
					wrapper.commit();

				}// for
			}// if

		} catch (Exception de) {
			wrapper.rollback();
			logger.error("err " + de.toString(), de);

			String param10 = "51";
			String param20 = (String) rowMap.get("COD_RCV_SEQ");
			wrapper.begin();
			wrapper.update("sce/SearchCSMSendCODEurTarget", "modifySceCodHis", new Object[] { param10, param20 });
			wrapper.commit();
			return;
		}

		logger.info("\n----------CSMSendCODEur End -------- ");

		return;
	}

	/**
	 * ArrayList - extracting hashmap from ResultTable and putting them into list
	 * 
	 * @param ResultTable
	 * @return ArrayList
	 * @throws EventException
	 */
	private ArrayList<HashMap<String, Object>> fetchRowSet(ResultTable svcLaneRS) throws EventException {
		if (svcLaneRS == null || svcLaneRS.getRowCount() < 0) {
			return null;
		}

		ArrayList<HashMap<String, Object>> rowList = null;
		try {
			rowList = new ArrayList<HashMap<String, Object>>();
			for (int j = 0; j < svcLaneRS.getRowCount(); j++) {
				rowList.add(svcLaneRS.getValues(j));
			}
		} catch (Exception se) {
			logger.error("err " + se.toString(), se);
			throw new EventException(se.getMessage());
		}
		return rowList;
	}
}
